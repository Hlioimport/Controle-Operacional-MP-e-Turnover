OPERACAO PESSOAL — VERSAO ANDROID / INTERATIVA

O que existe neste pacote:
- index.html: app interativo offline, já carregado com os dados das 3 abas.
- android-source/: projeto Android Studio (WebView local) que empacota o app para APK.
- operacao-pessoal-corrigido.xlsx: cópia corrigida da planilha original.
- operacao-pessoal-correcoes-formulas.txt: relatório célula a célula das fórmulas corrigidas.

Fluxo do aplicativo:
1. Edite ou inclua operadores na tela Operadores.
2. Edite ou inclua MPs na tela Movimentações.
3. Volte à Visão geral: o Quadro operacional ao vivo e as Movimentações ao vivo são atualizados imediatamente.
4. Informe o nome da sessão para registrar Hélio ou Felipe na auditoria.
5. Use Backup JSON para transportar os dados.

Os cálculos do quadro são feitos no próprio aplicativo; ele não depende de fórmulas do Excel nem de internet para atualizar a visão.

Para gerar o APK no Android Studio: abra android-source/, aguarde a sincronização do Gradle e use Build > Generate App Bundles or APKs > Generate APKs.
